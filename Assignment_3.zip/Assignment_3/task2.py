import math
num = int(input("Enter a number : "))

sqaure_root = math.sqrt(num)
logarithmic = math.log(num)
sine = math.sin(num)

print(f"Square root : {sqaure_root}")
print(f"Logarithm : {logarithmic} ")
print(f"Sin e : {sine} ")
