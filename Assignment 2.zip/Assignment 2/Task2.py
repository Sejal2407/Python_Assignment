sum = 0
for i in range(1,51):
    sum +=i

print(f"The Sum of numbers from 1 to 50 is {sum}")