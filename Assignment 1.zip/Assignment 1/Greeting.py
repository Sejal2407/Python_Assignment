first_name = input("Enter your first name : ")
last_name = input("Enter your last name : ")
full_name = first_name + " " + last_name
print("Hello ,",full_name,"! Welcome to python program")

'''
print("Hello !",first_name,last_name,"Welcome to python Program")
'''
