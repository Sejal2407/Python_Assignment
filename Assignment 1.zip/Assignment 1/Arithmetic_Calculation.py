"""
take 2 integer input from user and perform arithmetic operations
"""

num1 = int(input("Enter first number : "))
num2 = int(input("Enter second number : "))

add = num1 + num2
sub = num1 - num2
mul = num1 * num2
div = num1 / num2

print("Addition : ", add)
print("Subtraction : ",sub)
print("Multiplication : ",mul)
print("Division : ",div)

"""
print("Addition : ",add , "\nSubtraction : ",sub, "\n Multiplication : ",mul, "Division : ",div)
or 
print("Addition : ",num1 + num2)
print("Subtraction : ", num1 - num2)
"""